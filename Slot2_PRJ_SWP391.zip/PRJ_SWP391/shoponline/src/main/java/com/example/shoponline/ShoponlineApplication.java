package com.example.shoponline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoponlineApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoponlineApplication.class, args);
	}

}
