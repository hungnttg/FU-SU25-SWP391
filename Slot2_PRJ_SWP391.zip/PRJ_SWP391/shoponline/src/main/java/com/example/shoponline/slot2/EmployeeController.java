package com.example.shoponline.slot2;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/employee/api") //localhost:8080/employee/api
public class EmployeeController {
    //tham chieu den interface
    @Autowired
    private EmployeeRepository employeeRepository;
    //viet API
    @GetMapping("/high-salary")//localhost:8080/employee/api/high-salary
    public List<Employee> getEmployeesWithHighSalary(){
        return employeeRepository.findAll() //lay tat ca cac nhan vien
        .stream()
        .filter(nv -> nv.getSalary() >3000 )//loc cac nhan vien co muc luong >3000
        .collect(Collectors.toList());//chuyen thanh dang list
    }
}
