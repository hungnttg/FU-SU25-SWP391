package com.example.demo.slot3;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/slot3")
public class SanPhamController {
    @Autowired
    private SanPhamRepository repository;
    @GetMapping("/list")
    public String listSanPham(Model model){
        List<SanPham> list = repository.findAll();
        model.addAttribute("dssp", list);
        return "slot3/listproduct";
    }
}
